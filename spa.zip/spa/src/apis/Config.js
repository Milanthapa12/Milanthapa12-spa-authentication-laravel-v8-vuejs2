import axios from "axios";

let Config = axios.create({
  baseURL: "http://localhost:8000/api"
});
Config.defaults.withCredentials = true;
export default Config;
