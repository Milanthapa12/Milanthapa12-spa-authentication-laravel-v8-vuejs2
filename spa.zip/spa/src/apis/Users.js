import Config from "./Config.js";
import Csrf from "../apis/Csrf.js";

export default {
  async register(form) {
    await Csrf.getCookie();

    return Config.post("/register", form);
  },

  async login(form) {
    await Csrf.getCookie();

    return Config.post("/login", form);
  },

  async logout() {
    return Config.post("/logout");
  },

  auth() {
    return Config.get("/user");
  }
};
