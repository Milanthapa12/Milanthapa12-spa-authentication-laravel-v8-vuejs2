import Config from "./Config.js";
import Cookie from "js-cookie";

export default {
  getCookie() {
    let token = Cookie.get("XSRF-TOKEN");
    if (token) {
      return new Promise(resolve => {
        resolve(token);
      });
    }
    return Config.get("/csrf-cookie");
  }
};
