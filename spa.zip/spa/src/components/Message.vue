<template>
  <div>
    <modal
      name="modal-message"
      :adaptive="true"
      :clickToClose="false"
      :height="480"
      :width="800"
    >
      <button type="button" class="close" @click="close">
        &times;
      </button>
      <div class="message-container">
        dfgndkmglkdm
      </div>
    </modal>
  </div>
</template>
<script>
export default {
  methods: {
    close() {
      this.$modal.hide("modal-message");
    }
  }
};
</script>
