<template>
  <div class="advertisements">
    <div class="container">
      <div class="row">
        <slot name="ad-banner-one"></slot>
        <slot name="header"></slot>
      </div>
    </div>
  </div>
</template>
