<template>
  <div>
    <nav class="navbar navbar-expand-lg bg-default nav-settings">
      <div class="container">
        <router-link class="navbar-brand" to="/">Navbar</router-link>
        <button
          class="navbar-toggler"
          type="button"
          data-toggle="collapse"
          data-target="#navbarSupportedContent"
          aria-controls="navbarSupportedContent"
          aria-expanded="false"
          aria-label="Toggle navigation"
        >
          <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <ul class="navbar-nav">
            <li class="nav-item">
              <router-link
                class="nav-link"
                :to="{ name: 'Products', params: { name: 'men' } }"
                >Men</router-link
              >
            </li>
            <li class="nav-item">
              <router-link
                class="nav-link"
                :to="{ name: 'Products', params: { name: 'female' } }"
                >Female</router-link
              >
            </li>
            <li class="nav-item dropdown">
              <a
                class="nav-link dropdown-toggle"
                href="#"
                id="navbarDropdown"
                role="button"
                data-toggle="dropdown"
                aria-haspopup="true"
                aria-expanded="false"
              >
                Childern
              </a>
              <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                <router-link
                  class="dropdown-item"
                  :to="{
                    name: 'Sub-products',
                    params: { parent: 'children', name: 'infants' }
                  }"
                >
                  Infants
                </router-link>
                <router-link
                  class="dropdown-item"
                  :to="{
                    name: 'Sub-products',
                    params: { parent: 'children', name: 'toddlers' }
                  }"
                >
                  Toddlers
                </router-link>
                <router-link
                  class="dropdown-item"
                  :to="{
                    name: 'Sub-products',
                    params: { parent: 'children', name: 'kids' }
                  }"
                >
                  kids
                </router-link>
                <router-link
                  class="dropdown-item"
                  :to="{
                    name: 'Sub-products',
                    params: { parent: 'children', name: 'teenagers' }
                  }"
                >
                  Teenagers
                </router-link>
              </div>
            </li>
          </ul>
          <form class="form-inline my-2 my-lg-0 ml-auto">
            <input
              class="form-control mr-sm-5"
              type="search"
              placeholder="Search"
              aria-label="Search"
            />
            <ul class="navbar-nav parent-login my-2 my-lg-0 ml-auto">
              <li class="nav-item">
                <a v-if="isLoggedIn" class="nav-link px-5 py-2"
                  ><i class="fa fa-user-circle"></i>
                  User
                </a>
                <a
                  v-else
                  href="/#"
                  class="nav-link px-5 py-2"
                  @click.prevent="show"
                  >Login</a
                >
                <ul class="login-menu">
                  <li>
                    <a
                      v-if="!isLoggedIn"
                      href="/#"
                      @click.prevent="showRegisterForm"
                      ><span>New Customer?</span>
                      Register
                      <!--  <a
                        href="/#"
                        class="nav-link px-5 py-2"
                        @click.prevent="showRegisterForm"
                        >Register</a
                      > -->
                    </a>
                  </li>
                  <li>
                    <router-link to="/"
                      ><i class="fa fa-user-circle"></i>My Profile
                    </router-link>
                  </li>
                  <li>
                    <router-link to="/"
                      ><i class="fa fa-shopping-bag"></i>Orders
                    </router-link>
                  </li>
                  <li>
                    <router-link to="/"
                      ><i class="fa fa-heart"></i>Wishlists
                    </router-link>
                  </li>
                  <li>
                    <a v-if="isLoggedIn" href="" @click.prevent="logout"
                      >Logout
                      <i class="fa fa-sign-out-alt"></i>
                    </a>
                    <!--  <router-link to="/#" 
                      ><i class="fa fa-sign-out-alt"></i>
                    </router-link> -->
                  </li>
                </ul>
              </li>
              <li class="nav-item">
                <router-link class="nav-link mx-4" to="/">More</router-link>
                <!--             <ul class="login-menu">
                  <li>
                    <router-link to="/" class="more"
                      ><i class="fa fa-briefcase"></i>Sell on us
                    </router-link>
                  </li>
                  <li>
                    <router-link to="/"
                      ><i class="fa fa-headphones-alt"></i>24 x 7 customer care
                    </router-link>
                  </li>
                  <li>
                    <router-link to="/"
                      ><i class="fa fa-ad"></i>Advertise
                    </router-link>
                  </li>
                  <li>
                    <router-link to="/"
                      ><i class="fa fa-mobile-alt"></i>Download App
                    </router-link>
                  </li>
                </ul> -->
              </li>
              <li class="nav-item">
                <router-link class="nav-link mx-4" to="/">
                  <img
                    src="../assets/media-files/cart.png"
                    height="24"
                    width="24"
                    alt="Cart"
                  />
                  <sup>0</sup>
                </router-link>
              </li>
            </ul>
          </form>
        </div>
      </div>
    </nav>
  </div>
</template>
<script>
import User from "../apis/Users.js";
export default {
  name: "navbarComponent",
  data() {
    return {
      isLoggedIn: false
    };
  },
  mounted() {
    this.$root.$on("login", () => {
      this.isLoggedIn = true;
    });
    this.isLoggedIn = !!localStorage.getItem("auth");
    console.log(this.isLoggedIn);
  },
  methods: {
    show() {
      this.$modal.show("modal-login");
    },
    showRegisterForm() {
      this.$modal.show("modal-register");
    },
    logout() {
      User.logout().then(() => {
        this.isLoggedIn = false;
        localStorage.removeItem("auth");
        this.$router.push({
          name: "Home"
        });
      });
    }
  }
};
</script>
