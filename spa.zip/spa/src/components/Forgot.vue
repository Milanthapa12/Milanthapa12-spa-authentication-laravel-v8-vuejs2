<template>
  <div>
    <modal
      name="modal-forgot"
      :adaptive="true"
      :clickToClose="false"
      :height="300"
      :width="800"
    >
      <button type="button" class="close" @click="close">
        &times;
      </button>
      <div class="authenticate-container">
        <div class="bg-forgot">
          <img src="../assets/media-files/icons/forgot-pass.svg" alt="forgot" />
        </div>

        <div class="forgot">
          <p>Recover your password</p>
          <div class="form-group text-center">
            <input
              type="email"
              name="email"
              id="email"
              placeholder="EMAIL..."
              class="form-control"
              @keydown.shift.tab.prevent
            />
          </div>
          <div class="w-100 forgot-submit">
            <input
              type="submit"
              value="RESET PASSWORD"
              class="btn btn-primary w-100"
            />
          </div>
        </div>
      </div>
    </modal>
  </div>
</template>
<style scoped>
button.close {
  position: absolute;
  top: 4px;
  right: 8px;
  font-size: 30px;
}
.forgot p {
  text-align: left;
  font-size: 24px;
}
input[type="email"],
button {
  box-shadow: none;
  border-radius: 0px;
}
input[type="email"]::placeholder {
  /* Chrome, Firefox, Opera, Safari 10.1+ */
  font-size: 11px;
  font-weight: 600;
  color: #000;
  opacity: 0.6; /* Firefox */
}
.forgot-submit input[type="submit"] {
  border-radius: 0px;
  font-size: 14px;
  font-weight: 600;
}
</style>
<script>
export default {
  name: "Forgot",
  methods: {
    close() {
      this.$modal.hide("modal-forgot");
    },
    show() {
      this.$modal.hide("modal-login");
      this.$modal.show("modal-register");
    }
  }
};
</script>
