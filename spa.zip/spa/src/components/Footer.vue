<template>
  <div class="footer">
    <div class="customer-support">
      <div class="customer-support-title">
        Customer Support
      </div>
      <div class="contact-number">
        <i class="fa fa-phone-alt"></i><span>+977-9861333022</span>
      </div>
      <div class="work-period">
        <i class="fa fa-building"></i
        ><span>Sunday - Friday: 10:00 AM to 10:00 PM</span>
      </div>
      <div class="email">
        <i class="fa fa-envelope-open"></i
        ><span>hamroshopping@info.com.np</span>
      </div>
    </div>
    <div class="footer-logo"></div>
  </div>
</template>
