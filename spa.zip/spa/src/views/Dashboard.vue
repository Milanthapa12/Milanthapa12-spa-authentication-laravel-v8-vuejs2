<template>
  <div class="container">
    <div class="row">
      <div class="col-md-12 my-5">
        <h2>Dashboard</h2>
        <div v-if="user">
          Welcome {{ user.name }} Your email address: {{ user.email }}
        </div>
      </div>
    </div>
  </div>
</template>
<script>
import User from "../apis/Users.js";
export default {
  data() {
    return {
      user: null
    };
  },
  mounted() {
    User.auth().then(response => {
      this.user = response.data;
      console.log(response.data);
    });
  }
};
</script>
